from dataclasses import dataclass #, field
from typing import ClassVar

@dataclass
class $classname:
    member: type
    member: type
    class_var: classVar


if __name__ == '__main__':
    obj = $classname(value, value)
